DROP TABLE IF EXISTS "tb_cuentasRemanente" CASCADE;
CREATE TABLE "tb_cuentasRemanente" (
	cdrmte VARCHAR(6),
	nombre VARCHAR(125)
);

COPY "tb_cuentasRemanente" (cdrmte, nombre) FROM stdin;
0	Remanente de Tesorería para gastos generales
01	Remanente de Tesorería
011	Fondos líquidos
012	Derechos pendientes del cobro
012.01	del presupuesto corriente
012.02	de presupuestos cerrados
012.03	de otras operaciones no presupuestarias
012.04	Ingresos realizados pendientes de aplicación definitiva
013	Obligaciones pendientes de pago
013.01	del presupuesto corriente
013.02	de presupuestos cerrados
013.03	de otras operaciones no presupuestarias
013.04	Pagos realizados pendientes de aplicación definitiva
02	Saldos de dudoso cobro
03	Exceso de financiación afectada
04	Saldo de obligaciones pendientes de aplicar al presupuesto a 31 de diciembre
05	Saldo de obligaciones por devolución de ingresos pendientes de aplicar al presupuesto a 31 de diciembre
1	Remanente de Tesorería para gastos generales ajustado
2	Partidas pendientes de aplicación
\.
