DROP TABLE IF EXISTS "tb_cuentasRemanente" CASCADE;
CREATE TABLE "tb_cuentasRemanente" (
	"cdrmte" VARCHAR(6),
	"nombre" VARCHAR(125)
);

INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('0     ', 'Remanente de Tesorería para gastos generales                                                                                 ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('01    ', 'Remanente de Tesorería                                                                                                       ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('011   ', 'Fondos líquidos                                                                                                              ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('012   ', 'Derechos pendientes del cobro                                                                                                ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('012.01', 'del presupuesto corriente                                                                                                    ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('012.02', 'de presupuestos cerrados                                                                                                     ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('012.03', 'de otras operaciones no presupuestarias                                                                                      ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('012.04', 'Ingresos realizados pendientes de aplicación definitiva                                                                      ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('013   ', 'Obligaciones pendientes de pago                                                                                              ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('013.01', 'del presupuesto corriente                                                                                                    ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('013.02', 'de presupuestos cerrados                                                                                                     ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('013.03', 'de otras operaciones no presupuestarias                                                                                      ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('013.04', 'Pagos realizados pendientes de aplicación definitiva                                                                         ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('02    ', 'Saldos de dudoso cobro                                                                                                       ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('03    ', 'Exceso de financiación afectada                                                                                              ');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('04', 'Saldo de obligaciones pendientes de aplicar al presupuesto a 31 de diciembre');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('05', 'Saldo de obligaciones por devolución de ingresos pendientes de aplicar al presupuesto a 31 de diciembre');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('1', 'Remanente de Tesorería para gastos generales ajustado');
INSERT INTO "tb_cuentasRemanente" ("cdrmte", "nombre") VALUES ('2', 'Partidas pendientes de aplicación');


