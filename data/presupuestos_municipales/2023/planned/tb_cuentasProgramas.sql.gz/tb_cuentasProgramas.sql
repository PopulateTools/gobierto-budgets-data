DROP TABLE IF EXISTS "tb_cuentasProgramas" CASCADE;
CREATE TABLE "tb_cuentasProgramas" (
	cdfgr VARCHAR(6),
	nombre VARCHAR(125)
);

COPY "tb_cuentasProgramas" (cdfgr, nombre) FROM stdin;
011	Deuda Pública
2	ACTUACIONES DE PROTECCIÓN Y PROMOCIÓN SOCIAL
433	Desarrollo empresarial
44	Transporte público
450	Administración General de Infraestructuras
46	Investigación, desarrollo e innovación
491	Sociedad de la información
931	Política económica y fiscal
932	Gestión del sistema tributario
934	Gestión de la deuda y de la tesorería
150	Administración General de Vivienda y urbanismo
415	Protección y desarrollo de los recursos pesqueros.
42	Industria y energía
463	Investigación científica, técnica y aplicada.
492	Gestión del conocimiento
92	Servicios de carácter general
93	Administración financiera y tributaria
13	Seguridad y movilidad ciudadana
17	Medio ambiente
23	Servicios Sociales y promoción social
320	Administración general de educación
412	Mejora de las estructuras agropecuarias y de los sistemas productivos
420	Administración General de Industria y energía
43	Comercio, turismo y pequeñas y medianas empresas
439	Otras actuaciones sectoriales
45	Infraestructuras
462	Investigación y estudios relacionados con los servicios públicos
926	Comunicaciones internas.
165	Alumbrado público
334	Promoción cultural
34	Deporte
410	Administración General de Agricultura, Ganadería y Pesca
440	Administración general del transporte
9	ACTUACIONES DE CARÁCTER GENERAL
924	Participación ciudadana
925	Atención a los ciudadanos.
163	Limpieza viaria.
211	Pensiones
33	Cultura
933	Gestión del patrimonio
16	Bienestar comunitario
172	Protección y mejora del medio ambiente
221	Otras prestaciones económicas a favor de empleados
312	Hospitales, servicios asistenciales y centros de salud.
340	Administración General de Deportes.
341	Promoción y fomento del deporte.
342	Instalaciones deportivas.
41	Agricultura, Ganadería y Pesca
91	Órganos de gobierno
920	Administración General
922	Coordinación y organización institucional de las entidades locales
94	Transferencias a otras Administraciones Públicas
941	Transferencias a Comunidades Autónomas
943	Transferencias a otras Entidades Locales
944	Transferencias a la Administración General del Estado
152	Vivienda.
3	PRODUCCIÓN DE BIENES PÚBLICOS DE CARÁCTER PREFERENTE
338	Fiestas populares y festejos
419	Otras actuaciones en agricultura, ganadería y pesca
423	Minería
430	Administración General de Comercio, turismo y pequeñas y medianas empresas
459	Otras infraestructuras
0	DEUDA PÚBLICA
170	Administración general del medio ambiente
171	Parques y jardines
330	Administración General de Cultura
4	ACTUACIONES DE CARÁCTER ECONÓMICO
452	Recursos Hidráulicos
49	Otras actuaciones de carácter económico
942	Transferencias a Entidades Locales territoriales
01	Deuda Pública
1	SERVICIOS PÚBLICOS BÁSICOS
22	Otras prestaciones económicas a favor de empleados
332	Bibliotecas y Archivos
431	Comercio
130	Administración General de la Seguridad y Protección Civil
133	Ordenación del tráfico y del estacionamiento
21	Pensiones
241	Fomento del Empleo
31	Sanidad
32	Educación
414	Desarrollo rural
422	Industria
425	Energía
442	Infraestructuras del transporte
912	Órganos de gobierno
923	Información básica y estadística
132	Seguridad y Orden Público
134	Movilidad urbana
15	Vivienda y urbanismo
164	Cementerios y servicios funerarios
24	Fomento del Empleo
453	Carreteras
454	Caminos vecinales.
136	Servicio de prevención y extinción de incendios
135	Protección civil
151	Urbanismo:planeamiento,gestión,ejecución y disciplina urbanística
1521	Promoción y gestión de vivienda de protección pública
1522	Conservación y rehabilitación de la edificación
153	Vías públicas
1531	Acceso a los núcleos de población
1532	Pavimentación de vías públicas
160	Alcantarillado
161	Abastecimiento domiciliario de agua potable
162	Recogida, gestión y tratamiento de residuos
1621	Recogida de residuos
1622	Gestión de residuos sólidos urbanos
1623	Tratamiento de residuos
1721	Protección contra la contaminación acústica, lumínica y atmosférica en las zonas urbanas
231	Asistencia social primaria
311	Protección de la salubridad pública
321	Creación de Centros docentes de enseñanza preescolar y primaria
322	Creación de Centros docentes de enseñanza secundaria
323	Funcionamiento de Centros docentes de enseñanza preescolar y primaria y educación especial
324	Funcionamiento de Centros docentes de enseñanza secundaria
325	Vigilancia del cumplimiento de la escolaridad obligatoria
326	Servicios complementarios de educación
327	Fomento de la convivencia ciudadana
3321	Bibliotecas Públicas
3322	Archivos
333	Equipamientos culturales y museos
336	Protección y gestión del Patrimonio Histórico-Artístico
337	Instalaciones de ocupación del tiempo libre
4311	Ferias
4312	Mercados, Abastos y Lonjas
4313	Comercio Ambulante
432	Información y promoción turística
441	Transporte de viajeros
4411	Transporte colectivo urbano de viajeros
4412	Otro transporte de viajeros
443	Transporte de mercancías
493	Protección de consumidores y usuarios
9231	Gestión del Padrón Municipal de Habitantes
929	Imprevistos, situaciones transitorias y contingencias de ejecución
\.
