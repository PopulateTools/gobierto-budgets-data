DROP TABLE IF EXISTS "tb_CCAA" CASCADE;
CREATE TABLE "tb_CCAA" (
	"CCAA" VARCHAR(2),
	"Nombre" VARCHAR(26)
);

CREATE INDEX "tb_CCAACCAA" ON "tb_CCAA" ("CCAA");

INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('01', 'Andalucía                 ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('02', 'Aragón                    ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('03', 'Principado de Asturias    ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('04', 'Illes Balears             ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('05', 'Canarias                  ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('06', 'Cantabria                 ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('07', 'Castilla y León           ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('08', 'Castilla-La Mancha        ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('09', 'Cataluña                  ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('10', 'Extremadura               ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('11', 'Galicia                   ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('12', 'Comunidad de Madrid       ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('13', 'Región de Murcia          ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('14', 'Cdad. Foral de Navarra    ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('15', 'País Vasco                ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('16', 'La Rioja                  ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('17', 'Comunitat Valenciana      ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('18', 'Ceuta                     ');
INSERT INTO "tb_CCAA" ("CCAA", "Nombre") VALUES ('19', 'Melilla                   ');


