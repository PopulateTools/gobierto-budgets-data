DROP TABLE IF EXISTS "tb_Provincias" CASCADE;
CREATE TABLE "tb_Provincias" (
	"Provincia" VARCHAR(2),
	"Nombre" VARCHAR(22),
	"CCAA" VARCHAR(2)
);

CREATE INDEX "tb_ProvinciasCCAA" ON "tb_Provincias" ("CCAA");

INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('01', 'Araba/Álava', '15');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('02', 'Albacete              ', '08');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('03', 'Alicante / Alacant    ', '17');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('04', 'Almería               ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('05', 'Avila                 ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('06', 'Badajoz               ', '10');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('07', 'Illes Balears         ', '04');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('08', 'Barcelona             ', '09');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('09', 'Burgos                ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('10', 'Cáceres               ', '10');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('11', 'Cádiz                 ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('12', 'Castellón / Castelló  ', '17');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('13', 'Ciudad Real           ', '08');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('14', 'Córdoba               ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('15', 'Coruña, A             ', '11');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('16', 'Cuenca                ', '08');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('17', 'Girona                ', '09');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('18', 'Granada               ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('19', 'Guadalajara           ', '08');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('20', 'Gipuzkoa', '15');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('21', 'Huelva                ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('22', 'Huesca                ', '02');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('23', 'Jaén                  ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('24', 'León                  ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('25', 'Lleida                ', '09');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('26', 'Rioja, La             ', '16');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('27', 'Lugo                  ', '11');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('28', 'Madrid                ', '12');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('29', 'Málaga                ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('30', 'Murcia                ', '13');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('31', 'Navarra               ', '14');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('32', 'Ourense               ', '11');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('33', 'Asturias              ', '03');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('34', 'Palencia              ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('35', 'Palmas, Las           ', '05');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('36', 'Pontevedra            ', '11');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('37', 'Salamanca             ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('38', 'Santa Cruz de Tenerife', '05');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('39', 'Cantabria             ', '06');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('40', 'Segovia               ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('41', 'Sevilla               ', '01');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('42', 'Soria                 ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('43', 'Tarragona             ', '09');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('44', 'Teruel                ', '02');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('45', 'Toledo                ', '08');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('46', 'Valencia / València   ', '17');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('47', 'Valladolid            ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('48', 'Bizkaia', '15');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('49', 'Zamora                ', '07');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('50', 'Zaragoza              ', '02');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('51', 'Ceuta                 ', '18');
INSERT INTO "tb_Provincias" ("Provincia", "Nombre", "CCAA") VALUES ('52', 'Melilla               ', '19');

ALTER TABLE "tb_Provincias" ADD CONSTRAINT "tb_CCAAtb_Provincias" FOREIGN KEY ("CCAA") REFERENCES "tb_CCAA" ("CCAA") ON UPDATE SET NULL ON DELETE SET NULL;

