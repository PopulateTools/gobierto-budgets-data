update "tb_cuentasEconomica" set cdcta = LTRIM(RTRIM(cdcta));
update "tb_cuentasEconomica" set nombre = LTRIM(RTRIM(nombre));
update "tb_cuentasProgramas" set cdfgr = LTRIM(RTRIM(cdfgr));
update "tb_cuentasProgramas" set nombre = LTRIM(RTRIM(nombre));
update "tb_economica" set cdcta = LTRIM(RTRIM(cdcta));
update "tb_funcional" set cdcta = LTRIM(RTRIM(cdcta));
update "tb_funcional" set cdfgr = LTRIM(RTRIM(cdfgr));
update tb_inventario set nombreente = LTRIM(RTRIM(nombreente));
update tb_inventario set nombreppal = LTRIM(RTRIM(nombreppal));

