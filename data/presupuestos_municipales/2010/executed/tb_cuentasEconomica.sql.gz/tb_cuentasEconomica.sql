DROP TABLE IF EXISTS "tb_cuentasEconomica" CASCADE;
CREATE TABLE "tb_cuentasEconomica" (
	tipreig VARCHAR(1),
	cdcta VARCHAR(6),
	nombre VARCHAR(125)
);

COPY "tb_cuentasEconomica" (tipreig, cdcta, nombre) FROM stdin;
G	1	CAP. I GASTOS DE PERSONAL
G	10	Órganos de gobierno y personal directivo
G	100	Retribuciones básicas y otras remuneraciones de los miembros de los órganos de gobierno
G	100.00	Retribuciones básicas
G	100.01	Otras remuneraciones
G	101	Retribuciones básicas y otras remuneraciones del personal directivo
G	101.00	Retribuciones básicas
G	101.01	Otras remuneraciones
G	107	Contribuciones a planes y fondos de pensiones
G	107.00	De los miembros de los órganos de gobierno
G	107.01	Del personal directivo
G	11	Personal eventual
G	110	Retribuciones básicas y otras remuneraciones de personal eventual
G	110.00	Retribuciones básicas
G	110.01	Retribuciones complementarias
G	110.02	Otras remuneraciones
G	117	Contribuciones a planes y fondos de pensiones
G	12	Personal Funcionario
G	120	Retribuciones básicas
G	120.00	Sueldos del Grupo A1
G	120.01	Sueldos del Grupo A2
G	120.02	Sueldos del Grupo B
G	120.03	Sueldos del Grupo C1
G	120.04	Sueldos del Grupo C2
G	120.05	Sueldos del Grupo E
G	120.06	Trienios
G	120.09	Otras retribuciones básicas
G	121	Retribuciones complementarias
G	121.00	Complemento de destino
G	121.01	Complemento específico
G	121.03	Otros complementos
G	122	Retribuciones en especie
G	124	Retribuciones de funcionarios en prácticas
G	124.00	Sueldos del Grupo A1
G	124.01	Sueldos del Grupo A2
G	124.02	Sueldos del Grupo B
G	124.03	Sueldos del Grupo C1
G	124.04	Sueldos del Grupo C2
G	124.05	Sueldos del Grupo E
G	124.06	Trienios
G	124.09	Otras retribuciones básicas
G	127	Contribuciones a planes y fondos de pensiones
G	13	Personal Laboral
G	130	Laboral Fijo
G	130.00	Retribuciones básicas
G	130.01	Horas extraordinarias
G	130.02	Otras remuneraciones
G	131	Laboral temporal
G	132	Retribuciones en especie
G	137	Contribuciones a planes y fondos de pensiones
G	14	Otro personal
G	143	Otro personal
G	147	Contribuciones a planes y fondos de pensiones
G	15	Incentivos al rendimiento
G	150	Productividad
G	151	Gratificaciones
G	152	Otros incentivos al rendimiento
G	153	Complemento de dedicación especial
G	16	Cuotas, prestaciones y gastos sociales a cargo del empleador
G	160	Cuotas sociales
G	160.00	Seguridad Social
G	160.08	Asistencia médico-farmacéutica
G	160.09	Otras cuotas
G	161	Prestaciones sociales
G	161.03	Pensiones excepcionales
G	161.04	Indemnizaciones al personal laboral por jubilaciones anticipadas
G	161.05	Pensiones a cargo de la Entidad local
G	161.07	Asistencia médico-farmaceútica a pensionistas
G	162	Gastos sociales del personal
G	162.00	Formación y perfeccionamiento del personal
G	162.01	Economatos y comedores
G	162.02	Transporte de personal
G	162.04	Acción social
G	162.05	Seguros
G	162.09	Otros gastos sociales
G	164	Complemento familiar
G	2	CAP. II  GASTOS EN BIENES CORRIENTES Y SERVICIOS
G	20	Arrendamientos y cánones
G	200	Arrendamientos de terrenos y bienes naturales
G	202	Arrendamientos de edificios y otras construcciones
G	203	Arrendamientos de maquinaria, instalaciones y utillaje
G	204	Arrendamientos de material de transporte
G	205	Arrendamientos de mobiliario y enseres
G	206	Arrendamientos de equipos para procesos de información
G	208	Arrendamientos de otro inmovilizado material
G	209	Cánones
G	21	Reparaciones, mantenimiento y conservación
G	210	Infraestructuras y bienes naturales
G	212	Edificios y otras construcciones
G	213	Maquinaria, instalaciones técnicas y utillaje
G	214	Elementos de transporte
G	215	Mobiliario
G	216	Equipos para procesos de información
G	219	Otro inmovilizado material
G	22	Material, suministros y otros
G	220	Material de oficina
G	220.00	Ordinario no inventariable
G	220.01	Prensa, revistas, libros y otras publicaciones
G	220.02	Material informático no inventariable
G	221	Suministros
G	221.00	Energía eléctrica
G	221.01	Agua
G	221.02	Gas
G	221.03	Combustibles y carburantes
G	221.04	Vestuario
G	221.05	Productos alimenticios
G	221.06	Productos farmacéuticos y material sanitario
G	221.10	Productos de limpieza y aseo
G	221.11	Suministros de repuestos de maquinaria, utillaje y elementos de transporte
G	221.12	Suministros de material electrónico, eléctrico y de telecomunicaciones
G	221.13	Manutención de animales
G	221.99	Otros suministros
G	222	Comunicaciones
G	222.00	Servicios de Telecomunicaciones
G	222.01	Postales
G	222.02	Telegráficas
G	222.03	Informáticas
G	222.99	Otros gastos en comunicaciones
G	223	Transportes
G	224	Primas de seguros
G	225	Tributos
G	225.00	Tributos estatales
G	225.01	Tributos de las Comunidades Autónomas
G	225.02	Tributos de las Entidades locales
G	226	Gastos diversos
G	226.01	Atenciones protocolarias y representativas
G	226.02	Publicidad y propaganda
G	226.03	Publicación en Diarios Oficiales
G	226.04	Jurídicos, contenciosos
G	226.06	Reuniones, conferencias y cursos
G	226.07	Oposiciones y pruebas selectivas
G	226.09	Actividades culturales y deportivas
G	226.99	Otros gastos diversos
G	227	Trabajos realizados por otras empresas y profesionales
G	227.00	Limpieza y aseo
G	227.01	Seguridad
G	227.02	Valoraciones y peritajes
G	227.04	Custodia, depósito y almacenaje
G	227.05	Procesos electorales
G	227.06	Estudios y trabajos técnicos
G	227.08	Servicios de recaudación a favor de la entidad
G	227.99	Otros trabajos realizados por otras empresas y profesionales
G	23	Indemnizaciones por razón del servicio
G	230	Dietas
G	230.00	De los miembros de los órganos de gobierno
G	230.10	Del personal directivo
G	230.20	Del personal no directivo
G	231	Locomoción
G	231.00	De los miembros de los órganos de gobierno
G	231.10	Del personal directivo
G	231.20	Del personal no directivo
G	233	Otras indemnizaciones
G	24	Gastos de publicaciones
G	240	Gastos de edición y distribución
G	25	Trabajos realizados por administraciones públicas y otras entidades públicas
G	26	Trabajos realizados por Instituciones sin fines de lucro
G	27	Gastos imprevistos y funciones no clasificadas
G	3	CAP. III  GASTOS FINANCIEROS
G	30	De Deuda Pública en euros
G	300	Intereses
G	301	Gastos de emisión, modificación y cancelación
G	309	Otros gastos financieros de Deuda Pública en euros
G	31	De préstamos y otras operaciones financieras en euros
G	310	Intereses
G	311	Gastos de formalización, modificación y cancelación
G	319	Otros gastos financieros de préstamos y otras operaciones financieras en euros
G	32	De Deuda Pública en moneda distinta del euro
G	320	Intereses
G	321	Gastos de emisión, modificación y cancelación
G	322	Diferencias de cambio
G	329	Otros gastos financieros de Deuda Pública en moneda distinta del euro
G	33	De préstamos y otras operaciones financieras en moneda distinta del euro
G	330	Intereses
G	331	Gastos de formalización, modificación y cancelación
G	332	Diferencias de cambio
G	339	Otros gastos financieros de préstamos y otras operaciones financieras en moneda distinta del euro
G	34	De depósitos, fianzas y otros
G	340	Intereses de depósitos
G	341	Intereses de fianzas
G	35	Intereses de demora y otros gastos financieros
G	352	Intereses de demora
G	353	Operaciones de intercambio financiero
G	357	Ejecución de avales
G	358	Intereses por operaciones de arrendamiento financiero (leasing)
G	359	Otros gastos financieros
G	4	CAP. IV  TRANSFERENCIAS CORRIENTES
G	40	A la Admistración General de la Entidad Local
G	41	A Organismos Autónomos de la Entidad Local
G	42	A la Administración del Estado
G	420	A la Administración General del Estado
G	421	A Organismos Autónomos y agencias del Estado
G	421.00	Al Servicio Público de Empleo Estatal
G	421.10	A otros organismos autónomos
G	422	A Fundaciones estatales
G	423	A sociedades mercantiles estatales, entidades públicas empresariales y otros organismos públicos
G	423.00	Subvenciones para fomento del empleo
G	423.10	Subvenciones para bonificación de intereses y primas de seguros
G	423.20	Subvenciones para reducir el precio a pagar por los consumidores
G	423.90	Otras subvenciones a sociedades mercantiles estatales, entidades públicas empresariales y otros organismos públicos
G	43	A la Seguridad Social
G	44	A entes públicos y sociedades mercantiles de la Entidad Local
G	440	Subvenciones para fomento del empleo
G	441	Subvenciones para bonificación de intereses y primas de seguros
G	442	Subvenciones para reducir el precio a pagar por los consumidores
G	449	Otras subvenciones a entes públicos y sociedades mercantiles de la Entidad Local
G	45	A Comunidades Autónomas
G	450	A la Administración General de las Comunidades Autónomas
G	451	A Organismos Autónomos y agencias de las Comunidades Autónomas
G	452	A fundaciones de las Comunidades Autónomas
G	453	A sociedades mercantiles, entidades públicas empresariales y otros organismos públicos dependientes de las Comunidades Autóno
G	453.00	Subvenciones para fomento del empleo
G	453.10	Subvenciones para bonificación de intereses y primas de seguros
G	453.20	Subvenciones para reducir el precio a pagar por los consumidores
G	453.90	Otras subvenciones a sociedades mercantiles, entidades públicas empresariales y otros organismos públicos dependientes de las
G	46	A Entidades Locales
G	461	A Diputaciones, Consejos o Cabildos insulares
G	462	A Ayuntamientos
G	463	A Mancomunidades
G	464	A Áreas Metropolitanas
G	465	A Comarcas
G	466	A otras Entidades que agrupen municipios
G	467	A Consorcios
G	468	A Entidades Locales Menores
G	47	A Empresas privadas
G	470	Subvenciones para fomento del empleo
G	471	Subvenciones para bonificación de intereses y primas de seguros
G	472	Subvenciones para reducir el precio a pagar por los consumidores
G	479	Otras subvenciones a Empresas privadas
G	48	A Familias e Instituciones sin fines de lucro
G	49	Al Exterior
G	6	CAP. VI  INVERSIONES REALES
G	60	Inversión nueva en infraestructura y bienes destinados al uso general
G	600	Inversiones en terrenos
G	609	Otras inversiones nuevas en infraestructuras y bienes destinados al uso general
G	61	Inversiones de reposición en infraestructura y bienes destinados al uso general
G	610	Inversiones en terrenos
G	619	Otras inversiones de reposición en infraestructuras y bienes destinados al uso general
G	62	Inversión nueva asociada al funcionamiento operativo de los servicios
G	621	Terrenos y bienes naturales
G	622	Edificios y otras construcciones
G	623	Maquinaria, instalaciones técnicas y utillaje
G	624	Elementos de transporte
G	625	Mobiliario
G	626	Equipos para procesos de información
G	627	Proyectos complejos
G	629	Otras inversiones nuevas asociadas al funcionamiento operativo de los servicios
G	63	Inversión de reposición asociada al funcionamiento operativo de los servicios
G	631	Terrenos y bienes naturales
G	632	Edificios y otras construcciones
G	633	Maquinaria, instalaciones técnicas y utillaje
G	634	Elementos de transporte
G	635	Mobiliario
G	636	Equipos para procesos de información
G	637	Proyectos complejos
G	639	Otras inversiones de reposición asociadas al funcionamiento operativo de los servicios
G	64	Gastos en inversiones de carácter inmaterial
G	640	Gastos en inversiones de carácter inmaterial
G	641	Gastos en aplicaciones informáticas
G	648	Cuotas netas de intereses por operaciones de arrendamiento financiero (leasing)
G	65	Inversiones gestionadas para otros entes públicos
G	650	Gastos en inversiones gestionadas para otros entes públicos
G	68	Gastos en inversiones de bienes patrimoniales
G	681	Terrenos y bienes naturales
G	682	Edificios y otras construcciones
G	689	Otros gastos en inversiones de bienes patrimoniales
G	69	Inversiones en bienes comunales
G	690	Terrenos y bienes naturales
G	692	Inversión en infraestructuras
G	7	CAP. VII  TRANSFERENCIAS DE CAPITAL
G	70	A la Administración General de la Entidad Local
G	71	A Organismos Autónomos de la Entidad Local
G	72	A la Administración del Estado
G	720	A la Administración General del Estado
G	721	A Organismos Autónomos y agencias
G	721.00	Al Servicio Público de Empleo Estatal
G	721.09	A otros organismos autónomos
G	722	A fundaciones estatales
G	723	A sociedades mercantiles estatales, entidades públicas empresariales y otros organismos públicos
G	73	A la Seguridad Social
G	74	A entes públicos y sociedades mercantiles de la Entidad local
G	75	A Comunidades Autónomas
G	750	A la Administración General de las Comunidades Autónomas
G	751	A Organismos Autónomos y agencias de las Comunidades Autónomas
G	752	A fundaciones de las Comunidades Autónomas
G	753	A sociedades mercantiles, entidades públicas empresariales y otros organismos públicos dependientes de las Comunidades Autóno
G	76	A Entidades Locales
G	761	A Diputaciones, Consejos o Cabildos
G	762	A Ayuntamientos
G	763	A Mancomunidades
G	764	A Áreas Metropolitanas
G	765	A Comarcas
G	766	A Entidades que agrupen Municipios
G	767	A Consorcios
G	768	A Entidades Locales Menores
G	77	A Empresas privadas
G	78	A Familias e Instituciones  sin fines de lucro
G	79	Al Exterior
G	8	CAP. VIII  ACTIVOS FINANCIEROS
G	80	Adquisición de Deuda del Sector Público
G	800	Adquisición de deuda del sector público a corto plazo
G	800.00	Al Estado
G	800.10	A Comunidades Autónomas
G	800.20	A Entidades locales
G	800.90	A otros subsectores
G	801	Adquisición de deuda del sector público a largo plazo
G	801.00	Al Estado
G	801.10	A Comunidades Autónomas
G	801.20	A Entidades locales
G	801.90	A otros subsectores
G	81	Adquisición de Obligaciones y Bonos fuera del sector público
G	810	Adquisición de obligaciones y bonos fuera del sector público a corto plazo. Desarrollo por sectores.
G	811	Adquisición de obligaciones y bonos fuera del sector público a largo plazo. Desarrollo por sectores.
G	82	Concesión préstamos al sector público
G	820	Préstamos a corto plazo
G	820.00	Al Estado
G	820.10	A Comunidades Autónomas
G	820.20	A Entidades locales
G	820.90	A otros subsectores
G	821	Préstamos a largo plazo
G	821.00	Al Estado
G	821.10	A Comunidades Autónomas
G	821.20	A Entidades locales
G	821.90	A otros subsectores
G	83	Concesión de préstamos fuera del sector público
G	830	Préstamos a corto plazo. Desarrollo por sectores.
G	831	Préstamos a largo plazo. Desarrollo por sectores.
G	84	Constitución de depósitos y fianzas
G	840	Depósitos
G	840.00	A corto plazo
G	840.10	A largo plazo
G	841	Fianzas
G	841.00	A corto plazo
G	841.10	A largo plazo
G	85	Adquisición de acciones y participaciones del sector público
G	850	Adquisición de acciones y participaciones del sector público
G	850.10	Adquisición de acciones y participaciones para compensar pérdidas
G	850.20	Adquisición de acciones y participaciones para financiar inversiones no rentables
G	850.90	Resto de adquisiciones de acciones dentro del sector público
G	86	Adquisición de acciones y participaciones fuera del sector público
G	860	Adquisición de acciones y participaciones fuera del sector público
G	860.10	De empresas nacionales
G	860.20	De empresas de la Unión Europea
G	860.90	De otras empresas
G	87	Aportaciones patrimoniales
G	870	Aportaciones a fundaciones
G	871	Aportaciones a consorcios
G	872	Aportaciones a otros entes
G	872.10	Aportaciones para compensar pérdidas
G	872.20	Aportaciones para financiar inversiones no rentables
G	872.90	Resto de aportaciones
G	9	CAP. IX  PASIVOS FINANCIEROS
G	90	Amortización de Deuda Pública en euros
G	900	Amortización de Deuda Pública en euros a corto plazo
G	901	Amortización de Deuda Pública en euros a largo plazo
G	91	Amortización de préstamos y de operaciones en euros
G	910	Amortización de préstamos a corto plazo de entes del sector público
G	911	Amortización de préstamos a largo plazo de entes del sector público
G	912	Amortización de préstamos a corto plazo de entes de fuera del sector público
G	913	Amortización de préstamos a largo plazo de entes de fuera del sector público
G	92	Amortización de Deuda Pública en moneda distinta del euro
G	920	Amortización de Deuda Pública en moneda distinta del euro a corto plazo
G	921	Amortización de Deuda Pública en moneda distinta del euro a largo plazo
G	93	Amortización de préstamos en moneda distinta del euro
G	930	Amortización de préstamos en moneda distinta del euro a corto plazo
G	931	Amortización de préstamos en moneda distinta del euro a largo plazo
G	94	Devolución de depósitos y fianzas
G	940	Devolución de depósitos
G	941	Devolución de fianzas
I	1	CAP. I IMPUESTOS DIRECTOS
I	10	Impuesto sobre la Renta
I	100	Impuestos sobre la Renta de las Personas Físicas
I	101	Impuesto sobre Sociedades
I	102	Impuesto sobre la Renta de No Residentes
I	11	Impuestos sobre el capital
I	110	Impuesto sobre Sucesiones y Donaciones
I	111	Impuesto sobre Patrimonio
I	112	Impuesto sobre Bienes Inmuebles. Bienes Inmubles de Naturaleza Rústica.
I	113	Impuesto sobre Bienes Inmuebles. Bienes inmuebles de Naturaleza Urbana.
I	114	Impuesto sobre Bienes Inmuebles. Bienes Inmuebles de características especiales.
I	115	Impuesto sobre Vehículos de Tracción Mecánica
I	116	Impuesto sobre Incremento del Valor de los Terrenos de Naturaleza Urbana
I	117	Impuesto sobre viviendas desocupadas
I	13	Impuesto sobre las Actividades Económicas
I	130	Impuesto sobre Actividades Económicas
I	16	Recargos sobre impuestos directos del Estado y de la Comunidad Autónoma
I	160	Sobre impuestos del Estado
I	161	Sobre impuestos de la Comunidad Autónoma
I	17	Recargos sobre impuestos directos de otros entes locales
I	170	En el Impuesto sobre Bienes Inmuebles
I	171	Recargo provincial en el Impuesto sobre Actividades Económicas
I	179	Otros recargos sobre impuestos directos de otros entes locales
I	18	Impuestos directos extinguidos
I	19	Otros impuestos directos
I	2	CAP. II IMPUESTOS INDIRECTOS
I	21	Impuestos sobre el Valor Añadido
I	210	Impuesto sobre el Valor Añadido
I	22	Sobre consumos específicos
I	220	Impuestos Especiales
I	220.00	Impuesto sobre el alcohol y bebidas derivadas
I	220.01	Impuesto sobre la cerveza
I	220.02	Impuesto sobre el vino y bebidas fermentadas
I	220.03	Impuesto sobre las labores del tabaco
I	220.04	Impuesto sobre hidrocarburos
I	220.05	Impuesto sobre determinados medios de transporte
I	220.06	Impuesto sobre productos intermedios
I	220.07	Impuesto sobre la energía
I	220.08	Impuesto sobre ventas minoristas de hidrocarburos
I	220.09	Exacción sobre la gasolina
I	26	Recargos sobre impuestos indirectos del Estado y de la Comunidad Autónoma
I	260	Sobre impuestos del Estado
I	261	Sobre impuestos de la Comunidad Autónoma
I	27	Recargos sobre impuestos indirectos de otros entes locales
I	270	Sobre impuestos de otros entes locales
I	28	Impuestos indirectos extinguidos
I	29	Otros impuestos indirectos
I	290	Impuesto sobre construcciones, instalaciones y obras
I	291	Impuesto sobre gastos suntuarios (Cotos de caza y pesca)
I	292	Arbitrio sobre importaciones y entregas de mercancías en Canarias (AIEM)
I	293	Impuesto general indirecto canario (IGIC)
I	294	Impuesto sobre la producción, los servicios y la importación (IPSI) de Ceuta y Melilla
I	295	Impuesto sobre primas de seguros
I	296	Impuesto sobre transmisiones patrimoniales y actos jurídicos documentados
I	299	Otros Impuestos indirectos
I	3	CAP. III TASAS Y OTROS INGRESOS
I	30	Tasas por la prestación de servicios públicos básicos
I	300	Servicio de abastecimiento de agua
I	301	Servicio de alcantarillado
I	302	Servicio de recogida de basuras
I	303	Servicio de tratamiento de residuos
I	304	Canon de saneamiento
I	309	Otras tasas por prestación de servicios básicos
I	31	Tasas por la prestación de servicios públicos de carácter social y preferente
I	310	Servicios hospitalarios
I	311	Servicios asistenciales
I	312	Servicios educativos
I	313	Servicios deportivos
I	319	Otras tasas por prestación de servicios de carácter preferente
I	32	Tasas por la realización de actividades de competencia local
I	320	Licencias de caza y pesca
I	321	Licencias urbanísticas
I	322	Cedulas de habitabilidad y licencias de primera ocupación
I	323	Tasas por otros servicios urbanísticos
I	324	Tasas sobre el juego
I	325	Tasa por expedición de documentos
I	326	Tasa por retirada de vehículos
I	329	Otras tasas por la realización de actividades de competencia local
I	33	Tasas por la utilización privativa o el aprovechamiento especial del dominio público local
I	330	Tasa de estacionamiento de vehículos
I	331	Tasa por entrada de vehículos
I	332	Tasa por utilización privativa o aprovechamiento especial por empresas explotadoras de servicios de suministros
I	333	Tasa por utilización privativa o aprovechamiento especial por empresas explotadoras de servicios de telecomunicaciones
I	334	Tasa por apertura de calas y zanjas
I	335	Tasa por ocupación de la vía pública con terrazas
I	336	Tasa por ocupación de la vía pública con suspensión temporal del tráfico rodado
I	337	Tasas por aprovechamiento del vuelo
I	338	Compensación de Telefónica de España S.A.
I	339	Otras tasas por utilización privativa del dominio público
I	34	Precios públicos
I	340	Servicios hospitalarios
I	341	Servicios asistenciales
I	342	Servicios educativos
I	343	Servicios deportivos
I	344	Entradas a museos, exposiciones, espectáculos
I	345	Servicio de transporte público urbano
I	349	Otros precios públicos
I	35	Contribuciones especiales
I	350	Para la ejecución de obras
I	351	Para el establecimiento o ampliación de servicios
I	36	Ventas
I	38	Reintegros de operaciones corrientes
I	380	Reintegro de avales
I	389	Otros reintegros de operaciones corrientes
I	39	Otros ingresos
I	391	Multas
I	391.00	Multas por infracciones urbanísticas
I	391.10	Multas por infracciones tributarias y análogas
I	391.20	Multas por infracciones de la Ordenanza de circulación
I	391.90	Otras multas y sanciones
I	392	Recargos del periodo ejecutivo y por declaración extemporánea sin requerimiento previo
I	392.00	Recargos por declaración extemporánea sin requerimiento previo
I	392.10	Recargo ejecutivo
I	392.11	Recargo de apremio
I	393	Intereses de demora
I	394	Prestación personal
I	395	Prestación de transporte
I	396	Ingresos por actuaciones de urbanización
I	396.00	Canon de urbanización
I	396.10	Cuotas de urbanización
I	397	Aprovechamientos urbanísticos
I	397.00	Canon por aprovechamientos urbanísticos
I	397.10	Otros ingresos por aprovechamientos urbanísticos
I	398	Indemnizaciones de seguros de no vida
I	399	Otros ingresos diversos
I	4	CAP. IV  TRANSFERENCIAS CORRIENTES
I	40	De la Administración General de la Entidad Local
I	41	De Organismos Autónomos de la Entidad Local
I	42	De la Administración del Estado
I	420	De la Administración General del Estado
I	420.00	Participación en los Tributos del Estado
I	420.10	Fondo Complementario de Financiación
I	420.20	Compensación por beneficios fiscales
I	420.90	Otras transferencias corrientes de la Administración General del Estado
I	421	De Organismos Autónomos y agencias estatales
I	421.00	Del Servicio Público de Empleo Estatal
I	421.90	De otros Organismos Autónomos y Agencias
I	422	De fundaciones estatales
I	423	De sociedades mercantiles estatales, entidades públicas empresariales y otros organismos públicos
I	423.00	De Loterías y Apuestas del Estado
I	423.90	De otras sociedades mercantiles estatales, entidades públicas empresariales y organismos públicos
I	43	De la Seguridad Social
I	44	De entes públicos y sociedades mercantiles de la Entidad local
I	440	De entes públicos
I	441	De sociedades mercantiles
I	45	De Comunidades Autónomas
I	450	De la Administración General de las Comunidades Autónomas
I	450.00	Participación en tributos de la Comunidad Autónoma
I	450.01	Otras transferencias incondicionadas
I	450.02	Transferencias corrientes en cumplimiento de convenios suscritos con la Comunidad Autónoma en materia de Servicios Sociales y
I	450.30	Transferencias corrientes en cumplimiento de convenios suscritos con la Comunidad Autónoma en materia de Educación
I	450.50	Transferencias corrientes en cumplimiento de convenios suscritos con la Comunidad Autónoma en materia de Empleo y Desarrollo
I	450.60	Otras transferencias corrientes en cumplimiento de convenios suscritos con la Comunidad Autónoma
I	450.80	Otras subvenciones corrientes de la Administración General de la Comunidad Autónoma
I	451	De Organismos Autónomos y agencias de las Comunidades Autónomas
I	452	De fundaciones de las Comunidades Autónomas
I	453	De sociedades mercantiles, entidades públicas empresariales y otros organismos públicos dependientes de las Comunidades Autón
I	46	De Entidades Locales
I	461	De Diputaciones, Consejos o Cabildos
I	462	De Ayuntamientos
I	463	De Mancomunidades
I	464	De Áreas Metropolitanas
I	465	De Comarcas
I	466	De Entidades que agrupen Municipios
I	467	De Consorcios
I	468	De Entidades Locales Menores
I	47	De Empresas Privadas
I	48	De Familias e Instituciones sin fines de lucro
I	49	Del Exterior
I	490	Del Fondo Social Europeo
I	491	Del Fondo de Desarrollo Regional
I	492	Del Fondo de Cohesión
I	493	Del Fondo Europeo Agrícola de Garantía (FEAGA)
I	494	Del Fondo Europeo Agrícola de Desarrollo Rural (FEADER)
I	495	Del FEOGA-Orientación
I	496	Del Fondo Europeo de la Pesca (FEP)
I	497	Otras transferencias de la Unión Europea
I	499	Otras tansferencias del exterior, excluyendo la Unión Europea
I	4t	Ajustes de Consolidacion
I	5	CAP. V INGRESOS PATRIMONIALES
I	50	Intereses de títulos y valores
I	500	Del Estado
I	501	De Organismos Autónomos y agencias
I	504	De sociedades mercantiles estatales, entidades públicas empresariales y otros organismos públicos
I	505	De Comunidades Autónomas
I	506	De Entidades locales
I	507	De empresas privadas
I	51	Intereses de anticipos y préstamos concedidos
I	511	A Organismos Autónomos y agencias
I	514	A sociedades mercantiles, entidades públicas empresariales y otros organismos públicos
I	518	A familias e instituciones sin ánimo de lucro
I	52	Intereses de depósitos
I	53	Dividendos y participación beneficios
I	531	De Organismos Autónomos y agencias
I	534	De Sociedades mercantiles, entidades públicas empresariales y otros organismos públicos
I	534.00	De sociedades y entidades dependientes de las entidades locales
I	534.10	De sociedades y entidades no dependientes de las entidades locales
I	537	De empresas privadas
I	54	Rentas de bienes inmuebles
I	541	Arrendamientos de fincas urbanas
I	542	Arrendamientos de fincas rústicas
I	544	Censos
I	549	Otras rentas de bienes inmuebles
I	55	Productos de concesiones y aprovechamientos especiales
I	550	De concesiones administrativas con contraprestación periódica
I	551	De concesiones administrativas con contraprestación no periódica
I	552	Derecho de superficie con contraprestación periódica
I	553	Derecho de superficie con contraprestación no periódica
I	554	Aprovechamientos agrícolas y forestales
I	554.00	Producto de explotaciones forestales
I	554.10	Fondo de mejora de montes
I	555	Aprovechamientos especiales con contraprestación
I	559	Otras concesiones y aprovechamientos
I	59	Otros ingresos patrimoniales
I	591	Beneficios por realización de inversiones financieras
I	592	Ingresos por operaciones de intercambio financiero
I	599	Otros ingresos patrimoniales
I	6	CAP. VI ENAJENACIÓN DE INVERSIONES REALES
I	60	De Terrenos
I	600	Venta de solares
I	601	Venta de fincas rústicas
I	602	Parcelas sobrantes de la vía pública
I	603	Patrimonio público del suelo
I	609	Otros terrenos
I	61	De las demás Inversiones reales
I	611	De inversiones de carácter inmaterial
I	612	De objetos valiosos
I	619	De otras inversiones reales
I	68	Reintegros por operaciones de capital
I	680	De ejercicios cerrados
I	7	CAP. VII TRANSFERENCIAS DE CAPITAL
I	70	De la Administración General de la Entidad Local
I	71	De Organismos Autónomos de la Entidad Local
I	72	De la Administración del Estado
I	720	De la Administración General del Estado
I	721	De Organismos Autónomos y agencias estatales
I	721.00	Del Servicio Público de Empleo Estatal
I	721.90	De otros Organismos Autónomos y agencias
I	722	De fundaciones estatales
I	723	De sociedades mercantiles estatales, entidades públicas empresariales y otros organismos públicos
I	723.00	De Loterías y Apuestas del Estado
I	723.90	De otras sociedades mercantiles estatales, entidades públicas empresariales y otros organismos públicos
I	73	De la Seguridad Social
I	74	De entes públicos y sociedades mercantiles de la Entidad local
I	740	De entes públicos
I	741	De sociedades mercantiles
I	75	De Comunidades Autónomas
I	750	De la Administración General de las Comunidades Autónomas
I	750.00	Subvenciones afectas a la amortización de préstamos y operaciones financieras
I	750.02	Transferencias de capital en cumplimiento de convenios suscritos con la Comunidad Autónoma en materia de Servicios Sociales y
I	750.30	Transferencias de capital en cumplimiento de convenios suscritos con la Comunidad Autónoma en materia de Educación
I	750.50	Transferencias de capital en cumplimiento de convenios suscritos con la Comunidad Autónoma en materia de Empleo y Desarrollo
I	750.60	Otras transferencias de capital en cumplimiento de convenios suscritos con la Comunidad Autónoma
I	750.80	Otras transferencias de capital de la Administración General de la Comunidad Autónoma
I	751	De Organismos Autónomos y agencias de las Comunidades Autónomas
I	752	De fundaciones de las Comunidades Autónomas
I	753	De sociedades mercantiles, entidades públicas empresariales y otros organismos públicos dependientes de las Comunidades Autón
I	76	De Entidades Locales
I	761	De Diputaciones, Consejos o Cabildos
I	762	De Ayuntamientos
I	763	De Mancomunidades
I	764	De Áreas Metropolitanas
I	765	De Comarcas
I	766	De otras Entidades que agrupen Municipios
I	767	De Consorcios
I	768	De Entidades Locales Menores
I	77	De Empresas Privadas
I	78	De Familias e Instituciones sin fines de lucro
I	79	Del Exterior
I	790	Del Fondo Social Europeo
I	791	Del Fondo de Desarrollo Regional
I	792	Del Fondo de Cohesión
I	793	Del Fondo Europeo Agrícola de Garantía (FEAGA)
I	794	Del Fondo Europeo Agrícola de Desarrollo Rural (FEADER)
I	795	Del FEOGA-Orientación
I	796	Del Fondo Europeo de la Pesca (FEP)
I	797	Otras transferencias de la Unión Europea
I	799	Otras transferencias del exterior, excluyendo la Unión Europea
I	7t	Ajustes de consolidacion
I	8	CAP. VIII ACTIVOS FINANCIEROS
I	80	Enajenación de Deuda del Sector Público
I	800	Enajenación de deuda del sector público a corto plazo
I	800.00	Del Estado
I	800.10	De Comunidades Autónomas
I	800.20	De Entidades locales
I	801	Enajenación de deuda del sector público a largo plazo
I	801.00	Del Estado
I	801.10	De Comunidades Autónomas
I	801.20	De Entidades locales
I	81	Enajenación de obligaciones y bonos fuera del sector público
I	810	Enajenación de obligaciones y bonos fuera del sector público a corto plazo
I	811	Enajenación de obligaciones y bonos fuera del sector público a largo plazo
I	82	Reintegro de préstamos y anticipos concedidos al sector público
I	820	Reintegro de préstamos y anticipos concedidos al sector público a corto plazo
I	820.00	Del Estado
I	820.10	De Comunidades Autónomas
I	820.20	De Entidades locales
I	821	Reintegro de préstamos y anticipos concedidos al sector público a largo plazo
I	821.00	Del Estado
I	821.10	De Comunidades Autónomas
I	821.20	De Entidades locales
I	83	Reintegros de préstamos de fuera del sector público
I	830	Reintegros de préstamos de fuera del sector público a corto plazo
I	831	Reintegros de préstamos de fuera del sector público a largo plazo
I	84	Devolución de depósitos y fianzas constituidos
I	840	Devolución de depósitos
I	841	Devolución de fianzas
I	85	Enajenación de acciones y participaciones del sector público
I	86	Enajenación de acciones y participaciones fuera del sector público
I	87	Remanente de Tesorería
I	870	Remanente de tesorería
I	870.00	Para gastos generales
I	870.10	Para gastos con financiación afectada
I	9	CAP. IX PASIVOS FINANCIEROS
I	90	Emisión de Deuda Pública en euros
I	900	Emisión de Deuda Pública en euros a corto plazo
I	901	Emisión de Deuda Pública en euros a largo plazo
I	91	Préstamos recibidos en euros
I	910	Préstamos recibidos a corto plazo de entes del sector público
I	911	Préstamos recibidos a largo plazo de entes del sector público
I	912	Préstamos recibidos a corto plazo de entes de fuera del sector público
I	913	Préstamos recibidos a largo plazo de entes de fuera del sector público
I	92	Emisión de Deuda Pública en moneda distinta del euro
I	920	Emisión de Deuda Pública en moneda distinta del euro a corto plazo
I	921	Emisión de Deuda Pública en moneda distinta del euro a largo plazo
I	93	Préstamos recibidos en moneda distinta del euro
I	930	Préstamos recibidos en moneda distinta del euro a corto plazo
I	931	Préstamos recibidos en moneda distinta del euro a largo plazo
I	94	Depósitos y fianzas recibidos
I	940	Depósitos recibidos
I	941	Fianzas recibidas
\.
